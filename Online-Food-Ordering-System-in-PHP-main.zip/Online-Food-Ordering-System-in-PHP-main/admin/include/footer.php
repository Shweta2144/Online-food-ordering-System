 <footer class="footer" style="text-align: center;">Code Camp BD © 2023 - Online Food Ordering System Developer - <a href="https://www.facebook.com/dev.mhrony">MH RONY</a> </footer>
 <!--/*!
 * Author Name: MH RONY.
 * GigHub Link: https://github.com/dev-mhrony
 * Facebook Link:https://www.facebook.com/dev.mhrony
 * Youtube Link: https://www.youtube.com/channel/UChYhUxkwDNialcxj-OFRcDw
 for any PHP, Laravel, Python, Dart, Flutter work contact me at developer.mhrony@gmail.com
 * Visit My Website : developerrony.com

 */ -->